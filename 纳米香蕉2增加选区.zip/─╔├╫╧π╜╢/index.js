// index.js - NanoBanana Pro (强力双语修复版)

const MASK_CHANNEL_NAME = "Nano_AI_Mask_Temp";
let areaCounter = 1;
const MARK_COLORS = [{r: 0, g: 255, b: 0, name: "Green"}, {r: 255, g: 0, b: 0, name: "Red"}, {r: 0, g: 80, b: 255, name: "Blue"}, {r: 255, g: 255, b: 0, name: "Yellow"}];

function log(msg, isError = false) {
    const consoleDiv = document.getElementById('debug-console');
    if (!consoleDiv) return;
    const p = document.createElement('div');
    p.innerText = `> ${msg}`;
    if (isError) p.style.color = '#ff5555';
    consoleDiv.appendChild(p);
    consoleDiv.scrollTop = consoleDiv.scrollHeight;
}

document.addEventListener('DOMContentLoaded', () => {
    try {
        log("✅ 脚本已加载 (双语增强版)");
        
        const btnApi = document.getElementById('btn-to-api');
        const btnMain = document.getElementById('btn-to-main');
        if(btnApi) btnApi.addEventListener('click', () => switchPage('api'));
        if(btnMain) btnMain.addEventListener('click', () => switchPage('main'));
        
        const btnSave = document.getElementById('btn-save');
        const btnImport = document.getElementById('btn-import-key');
        const btnMark = document.getElementById('btn-mark');
        const btnMagic = document.getElementById('btn-magic-words'); 
        const btnDescribe = document.getElementById('btn-describe'); 
        const btnStart = document.getElementById('btn-start');       

        if(btnSave) btnSave.addEventListener('click', saveSettings);
        if(btnImport) btnImport.addEventListener('click', importKeyFile);
        if(btnMark) btnMark.addEventListener('click', markSelection);
        if(btnMagic) btnMagic.addEventListener('click', addMagicWords); 
        if(btnDescribe) btnDescribe.addEventListener('click', describeImage);
        if(btnStart) btnStart.addEventListener('click', runGenerate);

        const savedKey = localStorage.getItem('g3_key');
        if (savedKey) document.getElementById('apikey').value = savedKey;
        
        const savedUrl = localStorage.getItem('g3_base_url');
        document.getElementById('apiurl').value = savedUrl || "https://generativelanguage.googleapis.com";

        document.getElementById('model-gen').value = localStorage.getItem('g3_model_gen') || "gemini-3-pro-image-preview";
        document.getElementById('model-desc').value = localStorage.getItem('g3_model_desc') || "gemini-3-pro-preview";

        makeResizable('prompt', 'drag-prompt');
        makeResizable('prompt-cn', 'drag-prompt-cn');

    } catch (e) { log("初始化错误: " + e.message, true); }
});

function makeResizable(textAreaId, handleId) {
    const textArea = document.getElementById(textAreaId);
    const handle = document.getElementById(handleId);
    if(!textArea || !handle) return;
    handle.addEventListener('mousedown', function(e) {
        e.preventDefault();
        const startY = e.clientY;
        const startHeight = parseInt(document.defaultView.getComputedStyle(textArea).height, 10);
        function doDrag(e) { textArea.style.height = (startHeight + e.clientY - startY) + 'px'; }
        function stopDrag() {
            document.documentElement.removeEventListener('mousemove', doDrag, false);
            document.documentElement.removeEventListener('mouseup', stopDrag, false);
        }
        document.documentElement.addEventListener('mousemove', doDrag, false);
        document.documentElement.addEventListener('mouseup', stopDrag, false);
    });
}

function switchPage(page) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('show'));
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    if(page === 'main') {
        document.getElementById('page-main').classList.add('show');
        document.getElementById('btn-to-main').classList.add('active');
    } else {
        document.getElementById('page-api').classList.add('show');
        document.getElementById('btn-to-api').classList.add('active');
    }
}

function saveSettings() {
    let baseUrl = document.getElementById('apiurl').value.trim();
    if (baseUrl.endsWith('/')) baseUrl = baseUrl.slice(0, -1);
    if (!baseUrl) baseUrl = "https://generativelanguage.googleapis.com";

    localStorage.setItem('g3_key', document.getElementById('apikey').value);
    localStorage.setItem('g3_base_url', baseUrl);
    localStorage.setItem('g3_model_gen', document.getElementById('model-gen').value);
    localStorage.setItem('g3_model_desc', document.getElementById('model-desc').value);
    
    log("设置已保存");
    try{require("photoshop").app.showAlert("保存成功！");}catch(e){}
}

async function importKeyFile() {
    try {
        const fs = require("uxp").storage.localFileSystem;
        const file = await fs.getFileForOpening({ types: ["txt"] });
        if (!file) return;
        const text = await file.read();
        document.getElementById('apikey').value = text.trim();
        log("Key 导入成功");
    } catch (e) { log("导入失败: " + e.message, true); }
}

function addMagicWords() {
    const promptBox = document.getElementById('prompt');
    const magic = ", 8k resolution, photorealistic, masterpiece, best quality, highly detailed, cinematic lighting, ultra realistic, hdr, sharp focus";
    if(promptBox.value.indexOf("masterpiece") === -1) {
        promptBox.value += magic;
        log("✅ 已追加魔法词！");
    } else { log("提示: 已经加过了。"); }
}

function getBaseUrl() {
    let url = localStorage.getItem('g3_base_url');
    if (!url) url = "https://generativelanguage.googleapis.com";
    return url;
}

// === 🔍 反推功能 (强力修复版) ===
async function describeImage() {
    const promptBox = document.getElementById('prompt');
    const promptCnBox = document.getElementById('prompt-cn');
    
    promptBox.value = "正在分析画面...";
    promptCnBox.value = "正在翻译...";
    log("正在反推...");
    
    try {
        const key = localStorage.getItem('g3_key');
        if(!key) { log("错误: 缺 Key", true); return; }
        
        let model = document.getElementById('model-desc').value.toLowerCase().trim();
        let baseUrl = getBaseUrl();

        log(`使用 [${model}] 反推...`);
        const { base64 } = await getSafeBase64();
        
        const finalUrl = `${baseUrl}/v1beta/models/${model}:generateContent?key=${key}`;

        // 🔴 核心修改：使用更严格的 Prompt，强迫 AI 输出 JSON
        const systemPrompt = `
        You are an expert AI image tagger.
        1. Describe this image in detailed English for Stable Diffusion prompting.
        2. Translate that description into Chinese.
        
        Output STRICT JSON format ONLY. Do not output markdown code blocks.
        Format:
        {
            "english": "your English prompt here",
            "chinese": "你的中文翻译"
        }
        `;

        const res = await fetch(finalUrl, {
            method: "POST", headers: {"Content-Type": "application/json"},
            body: JSON.stringify({ contents: [{ parts: [ 
                {text: systemPrompt}, 
                {inline_data: {mime_type: "image/jpeg", data: base64}} 
            ]}] })
        });
        
        const json = await res.json();
        
        if (json.error) {
            log("API报错: " + json.error.message, true);
            promptBox.value = "API Error";
            promptCnBox.value = json.error.message;
        } 
        else if (json.candidates?.[0]?.content?.parts?.[0]?.text) {
            let rawText = json.candidates[0].content.parts[0].text;
            
            // 🧹 清理：有些模型喜欢加 \`\`\`json ... \`\`\`，我们手动删掉
            rawText = rawText.replace(/```json/gi, '').replace(/```/g, '').trim();

            try {
                // 尝试解析
                const result = JSON.parse(rawText);
                
                // ✅ 填入
                promptBox.value = result.english || rawText;
                promptCnBox.value = result.chinese || "未收到中文翻译";
                
                log("✅ 双语反推成功！");
            } catch (parseError) {
                // ❌ 如果解析失败，说明 AI 没听话返回了纯文本
                log("非JSON格式，显示原文", true);
                promptBox.value = rawText;
                promptCnBox.value = "AI 未返回标准格式，无法自动提取中文。";
            }
        } else { 
            log("反推失败: 无文本返回", true); 
        }
    } catch(e) { log("反推错: " + e.message, true); }
}

// === 生成功能 ===
async function runGenerate() {
    const btn = document.getElementById('btn-start');
    btn.innerText = "生成中...";
    log("🚀 开始生成...");
    
    try {
        const { app, core } = require("photoshop"); 
        const batchPlay = require("photoshop").action.batchPlay;
        
        const key = localStorage.getItem('g3_key');
        if(!key) { log("错误: 未设置 Key", true); return; }
        
        let model = document.getElementById('model-gen').value.toLowerCase().trim();
        let baseUrl = getBaseUrl();

        const originalDoc = app.activeDocument;
        const originalDocId = originalDoc.id;
        const targetWidth = originalDoc.width;
        const targetHeight = originalDoc.height;
        const targetRes = originalDoc.resolution;

        const { base64 } = await getSafeBase64();
        let prompt = document.getElementById('prompt').value || "Generate preview";
        
        log(`使用 [${model}] 生成...`);
        
        const finalUrl = `${baseUrl}/v1beta/models/${model}:generateContent?key=${key}`;

        const res = await fetch(finalUrl, {
            method: "POST", headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
                contents: [{ parts: [ {text: prompt}, {inline_data: {mime_type: "image/jpeg", data: base64}} ]}]
            })
        });

        const json = await res.json();
        
        if (json.candidates?.[0]?.content?.parts?.[0]?.inlineData) {
            log("📥 收到图片，处理中...");
            const imgB64 = json.candidates[0].content.parts[0].inlineData.data;
            const bin = atob(imgB64);
            const len = bin.length;
            const bytes = new Uint8Array(len);
            for (let i = 0; i < len; i++) bytes[i] = bin.charCodeAt(i);

            const fs = require("uxp").storage.localFileSystem;
            const formats = require("uxp").storage.formats;
            const ts = new Date().getTime();
            const tf = await fs.getTemporaryFolder();
            const rf = await tf.createFile(`gen_${ts}.jpg`, {overwrite: true});
            await rf.write(bytes, {format: formats.binary});

            await core.executeAsModal(async () => {
                const layers = originalDoc.layers;
                for (const layer of layers) {
                    if (layer.name.startsWith("NanoMarker_")) {
                        layer.delete();
                    }
                }
                log("🧹 已清理标记框");

                const newDoc = await app.open(rf);
                await newDoc.resizeImage(targetWidth, targetHeight, targetRes);
                
                await batchPlay([
                    { _obj: "duplicate", _target: [{ _ref: "layer", _enum: "ordinal", _value: "targetEnum" }], to: { _ref: "document", _id: originalDocId }, version: 5 }
                ], { synchronousExecution: true });
                
                await newDoc.closeWithoutSaving();

                let hasChannel = false;
                try { await batchPlay([{_obj:"get",_target:[{_ref:"channel",_name:MASK_CHANNEL_NAME}]}],{}); hasChannel = true; } catch(err) {}
                
                if (hasChannel) {
                    await batchPlay([{ _obj: "set", _target: {_ref: "channel", _property: "selection"}, to: {_ref: "channel", _name: MASK_CHANNEL_NAME} }], {});
                    await batchPlay([{ _obj: "make", new: {_class: "channel"}, at: {_ref: "channel", _enum: "channel", _value: "mask"}, using: {_enum: "userMaskEnabled", _value: "revealSelection"} }], {});
                    await batchPlay([{ _obj: "delete", _target: [{_ref: "channel", _name: MASK_CHANNEL_NAME}] }], {});
                    await batchPlay([{_obj:"set",_target:[{_ref:"channel",_property:"selection"}],to:{_enum:"ordinal",_value:"none"}}],{});
                    log("✅ 蒙版应用成功！");
                }
            }, { "commandName": "Clean & Place" });
            
            log("🎉 生成完毕！");
        } else if (json.candidates?.[0]?.content?.parts?.[0]?.text) {
            log("📄 收到文本回复: " + json.candidates[0].content.parts[0].text);
        } else {
            if (json.error) log("API错误: " + json.error.message, true);
            else log("未知返回: " + JSON.stringify(json), true);
        }

    } catch(e) { log("运行错误: " + e.message, true); }
    finally { btn.innerText = "开始生成 (图层置入)"; }
}

async function markSelection() {
    log("正在标记区域...");
    const { app, core } = require("photoshop");
    const batchPlay = require("photoshop").action.batchPlay;
    const doc = app.activeDocument;
    if(!doc) { log("请先打开图片", true); return; }

    await core.executeAsModal(async () => {
        try {
            const r = await batchPlay([{_obj:"get",_target:[{_property:"selection"},{_ref:"document",_enum:"ordinal",_value:"targetEnum"}]}],{synchronousExecution:true});
            if (!r[0] || !r[0].selection) {
                try{app.showAlert("⚠️ 请先画一个选区！");}catch(e){}
                return;
            }
            let hasChannel = false;
            try { await batchPlay([{_obj:"get",_target:[{_ref:"channel",_name:MASK_CHANNEL_NAME}]}],{}); hasChannel = true; } catch(err){}
            if (hasChannel) {
                await batchPlay([{_obj: "save", _target: {_ref: "selection"}, as: {_ref: "channel", _name: MASK_CHANNEL_NAME}, operation: {_enum: "selectionModifier", _value: "addToSelection"}}], {});
            } else {
                await batchPlay([{_obj: "save", _target: {_ref: "selection"}, as: {_obj: "channel", name: MASK_CHANNEL_NAME}}], {});
            }
            const color = MARK_COLORS[(areaCounter - 1) % MARK_COLORS.length];
            await batchPlay([{_obj:"make",_target:[{_ref:"layer"}],using:{_obj:"layer",name:`NanoMarker_${areaCounter}`}}],{});
            await batchPlay([{_obj: "stroke", _target: [{_ref:"document",_enum:"ordinal",_value:"targetEnum"}], using: {_obj: "stroke", width:{_unit:"pixelsUnit",_value:5}, location:{_enum:"strokeLocation",_value:"inside"}, color: {_obj:"RGBColor",red:color.r,green:color.g,blue:color.b}, opacity:{_unit:"percentUnit",_value:100}, mode:{_enum:"blendMode",_value:"normal"}}}], {});
            await batchPlay([{_obj:"set",_target:[{_ref:"channel",_property:"selection"}],to:{_enum:"ordinal",_value:"none"}}],{});
            const promptBox = document.getElementById('prompt');
            promptBox.value += `\n(Area ${areaCounter} is ${color.name}): `;
            promptBox.scrollTop = promptBox.scrollHeight;
            promptBox.focus();
            log(`✅ 区域 ${areaCounter} 已记录`);
            areaCounter++;
        } catch (e) { log("标记错误: " + e.message, true); }
    }, { "commandName": "Mark Area" });
}

async function getSafeBase64() {
    const { app, core } = require("photoshop");
    const fs = require("uxp").storage.localFileSystem;
    const formats = require("uxp").storage.formats;
    const doc = app.activeDocument;
    let base64 = "";

    await core.executeAsModal(async () => {
        const tempDoc = await doc.duplicate("temp_analysis");
        try {
            const maxDim = 1536;
            const scale = Math.min(maxDim / Math.max(tempDoc.width, tempDoc.height), 1);
            if(scale < 1) await tempDoc.resizeImage(tempDoc.width * scale, tempDoc.height * scale);

            const tempFolder = await fs.getTemporaryFolder();
            const tempFile = await tempFolder.createFile("temp.jpg", {overwrite:true});
            await tempDoc.saveAs.jpg(tempFile, {quality:7});
            const data = await tempFile.read({format: formats.binary});
            let binary = '';
            const bytes = new Uint8Array(data);
            for(let i=0; i<bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
            base64 = window.btoa(binary);
        } finally {
            await tempDoc.closeWithoutSaving();
        }
    }, { "commandName": "Read Image" });
    return { base64 };
}